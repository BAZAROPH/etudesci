<!doctype html>
<html>
<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-810KNX0NLR"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-810KNX0NLR');
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php if(isset($title)): ?> <?php echo e($title); ?> <?php endif; ?> - Etudes.ci</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/slick.css']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('icofont/icofont.min.css')); ?>">
    <link rel="icon" sizes="192x192" href="<?php echo e(asset('site/assets/favicon.png')); ?>">
</head>
<body>
    <?php echo $__env->make('site.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/js/slick.js']); ?>
    
    <script type="text/javascript" src="<?php echo e(asset('site/assets/js/tabs.js')); ?>"></script>
    
    <script type="text/javascript" src="<?php echo e(asset('site/assets/js/accordion.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('site/assets/js/search.js')); ?>"></script>

</body>
<?php if($active != 'workSpace' && $active != 'resume'): ?>
    <?php echo $__env->make('site.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
</html>
<?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/site/app.blade.php ENDPATH**/ ?>