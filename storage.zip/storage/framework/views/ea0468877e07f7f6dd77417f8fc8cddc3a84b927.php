<?php $__env->startSection('content'); ?>
    <?php if($ready): ?>
        <div>
            <div class="max-w-sm bg-etudes-blue mx-auto py-3 text-center text-xl text-white sticky top-20">
                Token <span class="p-1 text-white bg-etudes-orange rounded px-2 font-bold"><?php echo e(Auth::user()->token); ?></span>
            </div>
            <?php echo html_entity_decode($onlineClass->script); ?>

        </div>
    <?php else: ?>
        <div class="max-w-3xl mx-auto relative">
            <img src="<?php echo e($onlineClass->getFirstMediaUrl('onlineClass')); ?>" alt="">
            <div class="flex items-center text-etudes-orange text-xl font-semibold bg-etudes-blue mt-2 p-4 rounded-lg absolute top-0 right-0 mr-2" data-countdown="<?php echo e($onlineClass->date.' '.$onlineClass->hour); ?>">
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Suivre une online class',
    'active' => 'online-classrooms'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/site/subscriptions/onlineclass/meet.blade.php ENDPATH**/ ?>