<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Liste des cours</h4>
                <a href="<?php echo e(route('admin.course.create')); ?>">
                    <button class="btn btn-primary">Ajouter un cours</button>
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead>
                            <tr class="text-center">
                                <th>Identifiant</th>
                                <th>Image</th>
                                <th>Titre</th>
                                <th>Cabinet</th>
                                <th>Formateur</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($course->id); ?></td>
                                    <td>
                                        <img class='author-photo' src="<?php echo e($course->getFirstMediaUrl('courses')); ?>" alt="">
                                    </td>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($course->Office->name); ?></td>
                                    <td><?php echo e($course->Trainer->last_name); ?> <?php echo e($course->Trainer->first_name); ?></td>
                                    <td class="text-truncate">
                                        <?php if(!$course->published): ?>
                                            <a href="<?php echo e($course->publishedUrl()); ?>">
                                                <button data-toggle="modal" class="btn btn-primary text-white">Publier</button>
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e($course->publishedUrl()); ?>">
                                                <button data-toggle="modal" class="btn btn-warning text-white">Dépublier</button>
                                            </a>
                                        <?php endif; ?>
                                        <a href="<?php echo e($course->moduleUrl()); ?>">
                                            <button data-toggle="modal" class="btn btn-secondary text-white">Modules</button>
                                        </a>
                                        <a href="<?php echo e($course->editUrl()); ?>">
                                            <button data-toggle="modal" class="btn btn-success text-white">Modifier</button>
                                        </a>
                                        <button class="btn btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo e($course->id); ?>">Supprimer</button>
                                        <!-- DELETE Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo e($course->id); ?>">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Supprimer un d'auteurs</h5>
                                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(route('admin.course.delete')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="slug" value="<?php echo e($course->slug); ?>">
                                                            <div class="text-center text-black">
                                                                Êtes vous sûr de vouloir exécuter cette action ? <br/>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
                                                            <button type="submit" class="btn btn-danger">Supprimer</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>Identifiant</th>
                                <th>Image</th>
                                <th>Titre</th>
                                <th>Cabinet</th>
                                <th>Formateur</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste des cours',
    'active' => 'courses',
    'subActive' => 'courses-list'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/admin/courses/index.blade.php ENDPATH**/ ?>