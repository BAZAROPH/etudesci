<?php $__env->startSection('content'); ?>
<div class="py-10 bg-gradient-to-r from-etudes-blue/[.2] to-etudes-orange/[.1]">
    <div class="bg-white max-w-2xl mx-auto rounded pb-4">
        <div class="">
            <video src="<?php echo e(asset('site/assets/subscriptions/spot.mp4')); ?>" class="h-80 md:h-96 mx-auto rounded-xl md:mt-2 animate__animated animate__fadeInDown" autoplay muted loop controls></video>
        </div>
        <div class=" py-4 text-center font-bold text-white italic text-2xl">
            <span class="bg-etudes-orange px-2 py-1"><del class="text-sm pr-3 font-medium">50.000 Fcfa</del>14.900 Fcfa</span>
        </div>
        <hr class="my-2 border-2 border-black">
        <?php if(!Auth::check()): ?>

            
            <div class="max-w-sm mx-auto flex justify-center items-center border mt-4">
                <button class="py-2 text-lg font-semibold w-full duration-500 transition-all ease-in-out" id="connexion">Connexion</button>
                <button class="py-2 text-lg font-semibold subscribe-authtab-active w-full duration-500 transition-all ease-in-out" id="inscription">Inscription</button>
            </div>


            <form action="<?php echo e(route('subcription.login')); ?>" class="hidden" method="post" id="login-form">
                <?php echo csrf_field(); ?>
                <div id="login" class="mx-2 md:mx-8 p-2 mt-6 md:grid md:grid-cols-2 gap-4 border rounded-lg">
                    <div class="my-4 w-full text-center col-span-2 hidden" id="login-error">
                        <div class="bg-red-500/[.3] py-2 rounded-xl text-red-600"></div>
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Email</label><br>
                        <input id="login-email" type="email" name="email" class="border w-full py-1 rounded-lg px-2 focus:outline-none focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Mot de passe</label><br>
                        <input id="login-password" type="password" name="email" class="border w-full py-1 rounded-lg px-2 focus:outline-none focus:border-etudes-orange">
                    </div>
                    <div class="col-span-2 text-center mt-2">
                        <button id="login-button" type="button" class="w-full rounded py-1 bg-etudes-blue text-white hover:font-bold text-lg hover:uppercase hover:italic hover:bg-etudes-orange duration-500">Se Connecter</button>
                    </div>
                </div>
            </form>


            <form action="<?php echo e(route('subcription.register')); ?>" method="post" id="register-form">
                <?php echo csrf_field(); ?>
                <div id="register" class="mx-2 md:mx-8 p-2 mt-6 md:grid md:grid-cols-2 gap-4 border rounded-lg">
                    <div class="my-4 w-full text-center col-span-2 hidden" id="register-error">
                        <div class="bg-red-500/[.3] py-2 rounded-xl text-red-600"></div>
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Nom</label><br>
                        <input id="last-name" type="text" name="last_name" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Prénom</label><br>
                        <input id="first-name" type="text" name="first_name" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Email</label><br>
                        <input id="register-email" type="email" name="email" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Confirmez votre email</label><br>
                        <input id="confirm-email" type="email" name="confirmEmail" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="col-span-2">
                        <label class="text-sm text-gray-500" for="">Contact</label><br>
                        <input id="register-contact" type="text" name="contact" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Mot de passe</label><br>
                        <input id="register-password" type="password" name="password" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange">
                    </div>
                    <div class="">
                        <label class="text-sm text-gray-500" for="">Confirmez votre mot de passe</label><br>
                        <input id='confirm-password' type="password" name="confirm_password" class="border w-full mt-1 py-1 rounded-lg px-2 focus:outline-none focus:border focus:border-etudes-orange ">
                    </div>
                    <div class="col-span-2 text-center mt-2">
                        <button id="register-button" type="button" class="w-full rounded py-1 bg-etudes-blue text-white hover:font-bold text-lg hover:uppercase hover:italic hover:bg-etudes-orange duration-500">S'incrire</button>
                    </div>
                </div>
            </form>
        <?php endif; ?>

        <?php if(Auth::check()): ?>

        <div class="border mt-6 p-2 mx-2 md:mx-8 rounded-lg">
            <div>
                <img src="<?php echo e(asset('site/assets/subscriptions/bois.png')); ?>" class="h-12 mx-auto" alt="">
            </div>
            <div class="mx-2 md:mx-8 mt-4 space-y-4">
                <div class="my-4 w-full text-center col-span-2 hidden" id="contact-error">
                    <div class="bg-red-500/[.3] py-2 rounded-xl text-red-600"></div>
                </div>
                <div class="flex justify-between items-center">
                    <div class="w-1/4 md:w-1/2 font-semibold">
                        Email
                    </div>
                    <div class="w-3/4 md:w-1/2">
                        <span class="px-2 py-1 bg-etudes-orange uppercase font-bold italic text-white text-sm" id='user-email'><?php echo e(Auth::user()->email); ?></span>
                    </div>
                </div>
                <div class="flex justify-between items-center">
                    <div class="w-1/4 md:w-1/2 font-semibold">
                        Nom
                    </div>
                    <div class="w-3/4 md:w-1/2">
                        <span class="px-2 py-1 bg-etudes-orange uppercase font-bold italic text-white text-sm" id='user-last_name'><?php echo e(Auth::user()->last_name); ?></span>
                    </div>
                </div>
                <div class="flex justify-between items-center">
                    <div class="w-1/4 md:w-1/2 font-semibold">
                        Prénom
                    </div>
                    <div class="w-3/4 md:w-1/2">
                        <span class="px-2 py-1 bg-etudes-orange uppercase font-bold italic text-white text-sm" id='user-first_name'><?php echo e(Auth::user()->first_name); ?></span>
                    </div>
                </div>
                <?php if(is_null(Auth::user()->contact)): ?>
                    <div class="flex justify-between items-center">
                        <div class="w-1/4 md:w-1/2 font-semibold">
                            Contact
                        </div>
                        <div class="w-3/4 md:w-1/2">
                            <input id="contact" name="contact" type="text" class="border rounded-lg focus:rounded-none px-2 py-1 border-gray-300 focus:outline-none focus:border-etudes-orange uppercase font-bold italic focus:bg-etudes-orange focus:text-white duration-500 transition-all ease-in-out">
                        </div>
                    </div>
                <?php else: ?>
                    <div class="flex justify-between items-center">
                        <div class="w-1/4 md:w-1/2 font-semibold" >
                            Contact
                        </div>
                        <div class="w-3/4 md:w-1/2">
                            <span class="px-2 py-1 font-bold text-etudes-blue text-base" id="contact-value"><?php echo e(Auth::user()->contact); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="text-center pt-2">
                    <span class="font-semibold">Montant: </span>
                    <span class="text-etudes-orange font-bold italic text-xl">14.900 Fcfa</span>
                </div>
                <div class="flex flex-wrap justify-center md:justify-between items-center gap-6 md:gap-2">
                    <div class="flex items-center gap-2">
                        <input value="OMCIV2" checked type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method" id="payment-method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/OM.png')); ?>" class="h-8" id="payment-method" alt="">
                    </div>
                    <div class="flex items-center gap-2">
                        <input value="FLOOZ" type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/moov.png')); ?>" class="h-8" id="payment-method" alt="">
                    </div>
                    <div class="flex items-center gap-2">
                        <input value="MOMOCI" type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/mtn.png')); ?>" class="h-8" id="payment-method" alt="">
                    </div>
                    <div class="flex items-center gap-2">
                        <input value="WAVECI" type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/wave.png')); ?>" class="h-8" id="payment-method" alt="">
                    </div>
                    
                    <div class="flex items-center gap-2">
                        <input value="CARD" type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/visa.png')); ?>" class="h-5" alt="">
                    </div>
                    <div class="flex items-center gap-2">
                        <input value="CARD" type="radio" class="checked:accent-etudes-blue cursor-pointer" name="method">
                        <img src="<?php echo e(asset('site/assets/subscriptions/money/mastercard.png')); ?>" class="h-8" id="payment-method" alt="">
                    </div>
                    <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="id" id="user">

                </div>
                <div class="text-center">
                    <button id='pay-button' class="bg-etudes-blue text-white px-3 rounded font-bold italic py-1 w-full md:w-1/6 hover:w-full duration-300">Payer</button>
                </div>
            </div>
        </div>

        <?php else: ?>
            <div class="border mt-6 p-2 mx-8 rounded-lg">
                <div>
                    <img src="<?php echo e(asset('site/assets/subscriptions/bois.png')); ?>" class="h-12 mx-auto" alt="">
                </div>
                <div class="text-center py-4">
                    <i class="icofont-ui-lock text-7xl text-gray-400"></i>
                </div>
                <div class="text-center font-semibold text-gray-600 max-w-sm mx-auto">
                    Veuillez vous connecter ou créer un compte afin de continuer le paiement <i class="icofont-warning text-lg text-yellow-500"></i>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
var ROOT_URL = "<?php echo e(url('/')); ?>";
</script>
<script src="<?php echo e(asset('site/assets/js/subscription.js')); ?>"></script>
<script src="https://www.paiementpro.net/webservice/onlinepayment/js/paiementpro.v1.0.1.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Paiement',
    'active' => 'subscription-description',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/site/subscriptions/payment.blade.php ENDPATH**/ ?>