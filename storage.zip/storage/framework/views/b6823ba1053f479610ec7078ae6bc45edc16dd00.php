<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="badge-danger row mb-4 p-2 rounded text-center">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Liste des Paiements</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead>
                            <tr class="text-center">
                                <th>Références</th>
                                <th>N° Facture</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Id Produit</th>
                                <th>Montant</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($payment->references); ?></td>
                                    <td><?php echo e($payment->invoice); ?></td>
                                    <td><?php echo e($payment->User->last_name); ?></td>
                                    <td><?php echo e($payment->User->first_name); ?></td>
                                    <td><?php echo e($payment->product_type); ?></td>
                                    <td><?php echo e($payment->pay_at); ?></td>
                                    <td><?php echo e($payment->product_id); ?></td>
                                    <td><?php echo number_format($payment->amount). ' Fcfa'; ?></td>
                                    <td>
                                        <?php if($payment->state == 1): ?>
                                            <span  class="p-2 rounded bg-success text-white">Effectué</span>
                                        <?php else: ?>
                                            <span  class="p-2 rounded bg-warning text-white">En attente</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>Références</th>
                                <th>N° Facture</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Produit</th>
                                <th>Montant</th>
                                <th>Statut</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste des paiements',
    'active' => 'payments',
    'subActive' => 'payments-list'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>