<?php $__env->startSection('content'); ?>
<div class="">
    <div id="app" class="">

    </div>
</div>
<script type="text/javascript">
    var ROOT_URL = "<?php echo e(route('home')); ?>";
    var APP_NAME = "<?php echo e(config('app.name', 'Etudes.ci')); ?>";
    localStorage.setItem('token', "<?php echo e(session()->get('token')); ?>");
</script>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/resumes/App.jsx'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Je conçois mon CV',
    'active' => 'resume',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/site/resumes/index.blade.php ENDPATH**/ ?>