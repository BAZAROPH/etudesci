<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
<div class="badge-danger row mb-4 p-2 rounded text-center">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<div class="row mb-2">
    <div class="col-6 text-left text-center">
        <h4>Modifier de la online Class <?php echo e($onlineClass->title); ?></h4>
    </div>
    <div class="col-6 text-right">
        <a href="<?php echo e(route('admin.onlineClass.index')); ?>"><button class="btn btn-primary">Liste des online classrooms</button></a>
    </div>
    </div>
    <form action="<?php echo e(route('admin.onlineClass.update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        <input type="hidden" name="slug" value="<?php echo e($onlineClass->slug); ?>">
        <div class="row">
        <div class="col-4 text-center">
            <div id="file-block">
                <label id="upload-label" class="upload-label d-none">
                    <input name="image" class="file-input" id='image-input' onchange="handleImage(event)" type="file">
                    <i class="icofont-cloud-upload text-primary upload-icon"></i>
                </label>
                <div class="text-center">
                    <img id="image-preview" class="preview-image" src="<?php echo e($onlineClass->getFirstMediaUrl('onlineClass')); ?>" alt=""> <br>
                    <i id='delete-icon' class="icofont-ui-delete delete-image cursor-pointer" onclick="dropImage()"></i>
                </div>
            </div>
        </div>
        <div class="col-8 text-primary">
            <div class="row border-group">
                <div class="col-6 form-group">
                    <label for="title" class="required">Titre</label>
                    <input value="<?php echo e($onlineClass->title); ?>" type="text" name="title" class="form-control input-default " >
                </div>
                <div class="col-6 form-group">
                    <label for="trainer" class="required">Formateur</label>
                    <select value="<?php echo e($onlineClass->trainer); ?>" name="trainer" class="form-control input-default">
                        <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($trainer->id); ?>" <?php if($trainer->id == $onlineClass->Trainer->id): ?> selected='selected' <?php endif; ?>><?php echo e($trainer->last_name); ?> <?php echo e($trainer->first_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-6 form-group">
                    <label for="date" class="required">Date</label>
                    <input value="<?php echo e($onlineClass->date); ?>" type="date" name="date" class="form-control input-default" >
                </div>
                <div class="col-6 form-group">
                    <label for="hour" class="required">Heure</label>
                    <input value="<?php echo e($onlineClass->hour); ?>" type="time" name="hour" class="form-control input-default" >
                </div>
                <div class="col-12 form-group">
                    <label for="script" class="required">Script</label>
                    <input value="<?php echo e($onlineClass->script); ?>" type="text" name="script" class="form-control input-default" >
                </div>
                <div class="col-12 form-group">
                    <label for="type" class="required">Type</label>
                    <select name="type" class="form-control input-default">
                        <option value="onlineclass" <?php if($onlineClass->type == 'onlineclass'): ?> selected <?php endif; ?>>Onlineclass</option>
                        <option value="webinaire" <?php if($onlineClass->type == 'webinaire'): ?> selected <?php endif; ?>>Webinaire</option>
                    </select>
                </div>
                <div class="col-12">
                    <label for="description" class="required">Description</label>
                    <textarea id="summernote" class="summernote" name="description">
                        <?php echo e($onlineClass->description); ?>

                    </textarea>
                </div>
                <div class="col-12 mt-4">
                    <label for="description" class="required">Fichier Tokens</label><br>
                    <input type="file" accept=".csv" name="tokens">
                </div>
            </div>
            <div class="my-4 text-center">
                <button class="btn btn-primary">Enregistrer</button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste de online Classrooms',
    'active' => 'online-class',
    'subActive' => 'online-class'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/admin/onlineclass/update.blade.php ENDPATH**/ ?>