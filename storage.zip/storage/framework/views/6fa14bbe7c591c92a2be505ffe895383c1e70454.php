<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Liste des Abonnements</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example" class="display" style="min-width: 845px">
                            <thead>
                                <tr class="text-center">
                                    <th>Références de paiement</th>
                                    <th>Client</th>
                                    <th>Montant</th>
                                    <th>Statut</th>
                                    <th>Date de paiement</th>
                                    <th>Début d'abonnement</th>
                                    <th>Fin d'abonnement</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                       <td><?php echo e($subscription->references); ?></td>
                                       <td><?php echo e($subscription->User->last_name); ?> <?php echo e($subscription->User->first_name); ?></td>
                                       <td><?php echo e($subscription->amount); ?></td>
                                       <td>
                                            <?php if($subscription->state == 1): ?>
                                                <span  class="p-2 rounded bg-success text-white">Effectué</span>
                                            <?php else: ?>
                                                <span  class="p-2 rounded bg-warning text-white">En attente</span>
                                            <?php endif; ?>
                                        </td>
                                       <td><?php echo e($subscription->pay_at); ?></td>
                                       <td><?php echo e($subscription->start); ?></td>
                                       <td><?php echo e($subscription->end); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr class="text-center">
                                    <th>Références de paiement</th>
                                    <th>Client</th>
                                    <th>Montant</th>
                                    <th>Statut</th>
                                    <th>Date de paiement</th>
                                    <th>Début d'abonnement</th>
                                    <th>Fin d'abonnement</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste des Abonnements',
    'active' => 'subscription',
    'subActive' => 'subscription-list'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/admin/subscriptions/subscriptions.blade.php ENDPATH**/ ?>