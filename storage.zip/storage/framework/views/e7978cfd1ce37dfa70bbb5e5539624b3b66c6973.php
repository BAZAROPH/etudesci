<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="badge-danger row mb-4 p-2 rounded text-center">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="row mb-2">
        <div class="col-12 text-right">
            <a href="<?php echo e(route('admin.course.index')); ?>"><button class="btn btn-primary">Liste des cours</button></a>
        </div>
    </div>
    <form action="<?php echo e(route('admin.course.update')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="slug" value="<?php echo e($course->slug); ?>">
        <div class="row">
            <div class="col-4 text-center">
                <div id="file-block">
                    <label id="upload-label" class="upload-label d-none">
                        <input name="image" class="file-input" id='image-input' onchange="handleImage(event)" type="file">
                        <i class="icofont-cloud-upload text-primary upload-icon"></i>
                    </label>
                    <div class="text-center">
                        <img id="image-preview" class="preview-image" src="<?php echo e($course->getFirstMediaUrl('courses')); ?>" alt=""> <br>
                        <i id='delete-icon' class="icofont-ui-delete delete-image cursor-pointer" onclick="dropImage()"></i>
                    </div>
                </div>
            </div>
            <div class="col-8 text-primary">
                <div class="row border-group">
                    <div class="col-6 form-group">
                        <label for="title" class="required">Titre</label>
                        <input value="<?php echo e($course->title); ?>" type="text" name="title" class="form-control input-default " >
                    </div>
                    <div class="col-6 form-group">
                        <label for="office" class="required">Cabinet</label>
                        <select value="<?php echo e($course->office); ?>" name="office" class="form-control input-default">
                            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($office->id); ?>" <?php if($office->id == $course->Office->id): ?> selected='selected' <?php endif; ?>><?php echo e($office->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 form-group">
                        <label for="trainer" class="required">Formateur</label>
                        <select value="<?php echo e($course->trainer); ?>" name="trainer" class="form-control input-default">
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trainer->id); ?>" <?php if($trainer->id == $course->Trainer->id): ?> selected='selected' <?php endif; ?>><?php echo e($trainer->last_name); ?> <?php echo e($trainer->first_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 form-group">
                        <label for="youtube" class="required">Lien youtube</label>
                        <input value="<?php echo e($course->youtube); ?>" type="url" name="youtube" class="form-control input-default " >
                    </div>
                    <div class="col-6 form-group">
                        <label for="type" class="required">Type</label>
                        <select value="<?php echo e(old('type')); ?>" name="type" class="form-control input-default">
                            <option value="onlineclass" <?php if($course->type == 'onlineclass'): ?> selected <?php endif; ?>>Online Classroom</option>
                            <option value="course" <?php if($course->type == 'course'): ?> selected <?php endif; ?>>Cours</option>
                        </select>
                    </div>
                    <div class="col-6 form-group">
                        <label for="domaine" class="required">Domaine</label>
                        <select value="<?php echo e(old('domaines')); ?>" name="domaines[]" class="form-control input-default" multiple>
                            <?php $__currentLoopData = $domaines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domaine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($domaine->id); ?>" <?php if($course->Domaines->Contains('id', $domaine->id)): ?> selected='selected' <?php endif; ?>><?php echo e($domaine->label); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label for="description" class="">Description</label>
                        <textarea id="summernote" class="summernote" name="description">
                            <?php echo html_entity_decode($course->description); ?>

                        </textarea>
                    </div>
                </div>
                <div class="my-4 text-center">
                    <button class="btn btn-primary">Enregistrer</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Modifier un cours',
    'active' => 'cours',
    'subActive' => 'new-course'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/admin/courses/update.blade.php ENDPATH**/ ?>