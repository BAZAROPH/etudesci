<?php $__env->startSection('content'); ?>
<div class="bg-gradient-to-r from-etudes-blue/[.2] to-etudes-orange/[.1] pb-6">
    <div class="border-b pb-4 border-etudes-blue bg-gradient-to-r from-etudes-blue/[.4] to-etudes-orange/[.2] pt-5 relative">
        <?php if($actif): ?>
            <div class="absolute right-0 pr-4">
                <span class="font-bold text-etudes-blue">Abonnement: <span class="pl-4 text-base font-normal italic">Actif jusqu'au</span> <span class="px-1 text-white bg-etudes-orange italic"><?php echo e($subscription->endDate()); ?> à <?php echo e($subscription->endHour()); ?></span></span>
                <div class="mt-4 text-right">
                    <a href="<?php echo e(route('subcription.pay')); ?>">
                        <button class="text-white font-medium  bg-etudes-blue p-2 rounded-lg hover:w-full w-3/5 duration-300 hover:bg-etudes-orange hover:font-semibold">Prolonger mon abonnement</button>
                    </a>
                </div>
            </div>

        <?php else: ?>
            <div class="absolute right-0 pr-4">
                <span class="font-bold text-etudes-blue">Abonnement: <span class="pl-4 text-base font-normal italic">Inactif depuis le</span> <span class="px-1 text-white bg-red-600 italic"><?php echo e($subscription->endDate()); ?> à <?php echo e($subscription->endHour()); ?></span></span>
                <div class="mt-4 text-right">
                    <a href="">
                        <button class="text-white font-medium  bg-etudes-orange p-2 rounded-lg hover:w-full w-3/5 duration-300 hover:bg-etudes-blue hover:font-semibold">Renouveler mon abonnement</button>
                    </a>
                </div>
            </div>

        <?php endif; ?>
        <img src="<?php echo e(asset('site/assets/subscriptions/bois.png')); ?>" class="h-24 mx-auto" alt="">
        <div class="text-center text-4xl font-bois text-etudes-blue tracking-widest mt-4">
            Bienvenue dans votre espace sacré
        </div>
    </div>
    <div class="grid grid-cols-3 ">
        <div class="col-span-3">
            <div class="px-4 py-6">
                <div class="text-2xl text-etudes-orange font-medium">Prochaines Onlines Classroom <i class="icofont-ui-play pl-2"></i></div>
                <div class="max-w-6xl course-slide mx-auto flex">
                    <?php $__currentLoopData = $nextOnlineClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nextOnlineClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mx-auto">
                            <a href="<?php echo e(route('onlineClass.open', $nextOnlineClass->slug)); ?>">
                                <img src="<?php echo e($nextOnlineClass->getFirstMediaUrl('onlineClass')); ?>" class="h-56 w-full rounded-xl shadow-lg shadow-etudes-orange hover:scale-110 duration-500 hover:shadow-white" alt="">
                                
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="px-4 py-6">
                <div class="text-2xl text-etudes-blue font-medium">Mes Replay disponibles <i class="icofont-play-pause pl-2"></i></div>
                <div class="max-w-6xl course-slide mx-auto">
                    <?php $__currentLoopData = $previousOnlineClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previousOnlineClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mx-auto">
                            <a href="<?php echo e(route('onlineClass.open', $previousOnlineClass->slug)); ?>">
                                <img src="<?php echo e($nextOnlineClass->getFirstMediaUrl('onlineClass')); ?>" class="h-56 rounded-xl shadow-lg shadow-etudes-blue hover:brightness-50 hover:scale-110 duration-500 hover:shadow-white" alt="">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="px-20 pb-4 md:pb-0 flex flex-wrap justify-between items-center bg-etudes-blue">
                <div class="">
                    <div class="p-2">
                        <div class="mt-4">
                            <img src="<?php echo e(asset('site/assets/subscriptions/cv.jpeg')); ?>" class="h-64 rounded mx-auto" alt="">
                        </div>
                    </div>
               </div>
               <div class="">
                    <video src="<?php echo e(asset('site/assets/subscriptions/spot.mp4')); ?>" class="h-64" autoplay muted loop controls></video>
                </div>
               <div>
                    <ul class="text-center mt-2 font-semibold text-etudes-blue">
                        <li class=""><span class="text-white px-1 uppercase italic">Changez les couleurs</span></li>
                        <li class=""><span class="text-white px-1 uppercase italic">Accédez à plus de modeles</span></li>
                        <li class=""><span class="text-white px-1 uppercase italic">Partagez votre CV avec un lien</span></li>
                    <div class="text-center mt-2">
                        <button class="w-1/2 py-2 bg-etudes-orange text-white rounded-lg hover:w-2/3 duration-300 hover:font-bold">
                            Espace mon CV
                        </button>
                    </div>
               </div>
            </div>

            <div class="md:px-20">
                <div class="mt-6">
                    <div class="text-2xl text-etudes-blue font-medium">Quelques formations <i class="icofont-learn pl-2"></i></div>
                    <div class="course-slide">
                        <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="shadow-xl border rounded-xl h-full">
                                <div class="w-full">
                                    <a href="<?php echo e($certification->detailsUrl()); ?>">
                                        <img src="<?php echo e($certification->getFirstMediaUrl('certifications')); ?>" class="h-96 w-full " alt="">
                                    </a>
                                </div>
                                <div class="p-4">
                                    <div class="flex justify-between items-center text-gray-500">
                                        <div class="gap-4 flex items-center">
                                            <i class="icofont-ui-calendar text-etudes-orange"></i>
                                            <span><?php echo e($certification->carbonHumanDate()); ?></span>
                                        </div>
                                        <div>
                                            <i class="icofont-location-pin text-etudes-blue"></i>
                                            <?php if($certification->location_type == 'online'): ?>
                                                En ligne
                                            <?php else: ?>
                                                En présentiel
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-1">
                                        <a href="<?php echo e($certification->detailsUrl()); ?>">
                                            <?php echo e($certification->title); ?>

                                        </a>
                                    </div>
                                    <div class=" flex justify-left gap-5 items-center">
                                        <img src="<?php echo e(asset('site/assets/test/certificats_1662043814.png')); ?>" class="h-14 w-14 rounded-full  border border-etudes-blue" alt="">
                                        <span class="capitalize text-etudes-blue tracking-widest"><?php echo e($certification->Office->name); ?></span>
                                    </div>
                                </div>
                                <div class="border-gray-300 border-t p-4 flex justify-between items-center">
                                    <span class="text-etudes-orange font-bold text-xl">
                                        <?php echo number_format($certification->premium_price). ' Fcfa'; ?> <i class="icofont-star"></i>
                                    </span>
                                    <del class="text-gray-500 font-bold text-xl">
                                        <?php if($certification->reduction): ?>
                                            <?php echo number_format($certification->price - ($certification->price * ($certification->reduction/100))). ' Fcfa'; ?>
                                        <?php else: ?>
                                            <?php echo number_format($certification->price). ' Fcfa'; ?>
                                        <?php endif; ?>
                                    </del>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="md:px-20">
                <div class="mt-6">
                    <div class="text-2xl text-etudes-blue font-medium">Quelques évènements <i class="icofont-learn pl-2"></i></div>
                    <div class="course-slide">
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="shadow-xl border rounded-xl">
                            <div class="w-full">
                                <a href="<?php echo e($event->detailsUrl()); ?>">
                                    <img src="<?php echo e($event->getFirstMediaUrl('events')); ?>" class="h-80 w-full rounded-t-xl" alt="">
                                </a>
                            </div>
                            <div class="p-4">
                                <div class="flex justify-left items-center gap-2 text-gray-500 text-sm">
                                    <div class=" gap-2 flex items-center">
                                        <i class="icofont-ui-calendar text-etudes-orange"></i>
                                        <span><?php echo e($event->carbonHumanDate()); ?></span>
                                    </div>
                                    <div>|</div>
                                    <div>
                                        <i class="icofont-stopwatch text-etudes-blue"></i>
                                        <span><?php echo e($event->carbonHumanHour()); ?> GMT</span>
                                    </div>
                                </div>
                                <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-1">
                                    <?php echo e($event->name); ?>

                                </div>
                            </div>
                            <div class="border-gray-300 border-t p-4">
                                <i class="icofont-location-arrow text-etudes-blue"></i>
                                <?php echo e($event->place); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Mon Espace',
    'active'=> 'user-space',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/site/space/space.blade.php ENDPATH**/ ?>