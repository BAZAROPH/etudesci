<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Liste des cours</h4>
                <div>
                    <a href="<?php echo e(route('admin.onlineClass.create')); ?>">
                        <button class="btn btn-primary">Ajouter une online class</button>
                    </a>
                    <a href="<?php echo e(route('admin.onlineClass.trash')); ?>"><button class="btn btn-secondary">Corbeille</button></a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead>
                            <tr class="text-center">
                                <th>Image</th>
                                <th>Titre</th>
                                <th>Date</th>
                                <th>Heure</th>
                                <th>Speaker</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $onlineClasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onlineClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><img class='author-photo' src="<?php echo e($onlineClass->getFirstMediaUrl('onlineClass')); ?>" alt=""></td>
                                    <td class="text-center"><?php echo e($onlineClass->title); ?></td>
                                    <td class="text-center"><?php echo e($onlineClass->date); ?></td>
                                    <td class="text-center"><?php echo e($onlineClass->hour); ?></td>
                                    <td class="text-center"><?php echo e($onlineClass->Trainer->first_name); ?> <?php echo e($onlineClass->Trainer->last_name); ?></td>
                                    <td class="text-truncate text-center">
                                        <a href="<?php echo e($onlineClass->editUrl($onlineClass->slug)); ?>">
                                            <button data-toggle="modal" class="btn btn-warning text-white">Modifier</button>
                                        </a>
                                        <button data-toggle="modal" data-target="#deleteModal<?php echo e($onlineClass->id); ?>" class="btn btn-danger text-white">Supprimer</button>
                                        <!-- DELETE Modal -->
                                        <div class="modal fade" id="deleteModal<?php echo e($onlineClass->id); ?>">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">Supprimer <?php echo e($onlineClass->title); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(route('admin.onlineClass.delete')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="slug" value="<?php echo e($onlineClass->slug); ?>">
                                                            <div class="text-center text-black">
                                                                Êtes vous sûr de vouloir exécuter cette action ? <br/>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-primary" data-dismiss="modal">Fermer</button>
                                                            <button type="submit" class="btn btn-danger">Supprimer</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>Image</th>
                                <th>Titre</th>
                                <th>Date</th>
                                <th>Heure</th>
                                <th>Speaker</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste de online Classrooms',
    'active' => 'online-class',
    'subActive' => 'online-class'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/admin/onlineclass/index.blade.php ENDPATH**/ ?>