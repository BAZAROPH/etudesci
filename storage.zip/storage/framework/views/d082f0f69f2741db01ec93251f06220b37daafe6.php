<?php $__env->startSection('content'); ?>
<div class="mb-16">
    <div class="h-56 bg-etudes-blue">
        <div class="mx-10 p-10 text-5xl text-white grid place-items-center h-full">
            <div class="text-left w-full">
                <div class="font-semibold">Nos cours</div>
                <div class="h-10 bg-etudes-orange mt-4 max-w-md rounded-lg flex items-center justify-left text-sm px-4 gap-4">
                    <div>
                        <a href="<?php echo e(route('home')); ?>">
                            Accueil
                        </a>
                    </div>
                    <span>-</span>
                    <div class="font-bold">
                        Liste des cours
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="max-w-sm md:max-w-6xl my-8 mx-auto">
        <div class="my-5 bg-gray-200 rounded-lg p-4 flex items-center justify-between gap-4">
            <div class="flex justify-between items-center w-3/5 border-2 border-gray-300 p-1 rounded-xl peer">
                <input type="text" class="bg-transparent w-full px-2 focus:outline-none text-etudes-blue placeholder-etudes-blue search-input" <?php if(!$domaines->contains('label', $subject) && !is_null($subject)): ?> value="<?php echo e($subject); ?>" <?php endif; ?> placeholder="Rechercher un cours ...">
                <button class="bg-etudes-blue text-white px-2 py-1 rounded-xl search-button">
                    <i class="icofont-search-2"></i>
                </button>
            </div>
            <select name="" class="w-2/5 bg-white py-3 px-2 rounded-lg search-select" link='<?php echo e(route('course.list')); ?>' id="">
                <option value="">Trier par domaine</option>
                <?php $__currentLoopData = $domaines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domaine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($domaine->label); ?>" <?php if($domaine->label == $subject): ?> selected='selected' <?php endif; ?>><?php echo e($domaine->label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="my-8 grid grid-cols-1 md:grid-cols-3 gap-10 items-start">
            <div class="col-span-2">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="bg-white shadow-xl <?php echo e($course->type == 'onlineclass' ? 'shadow-etudes-orange rounded-xl' : 'shadow-etudes-blue/[.3]'); ?> rounded-xl">
                            <div>
                                <a href="<?php echo e($course->detailsUrl()); ?>">
                                    <img src="<?php echo e($course->getFirstMediaUrl('courses')); ?>" class="h-60 w-full mx-auto rounded-t-xl" alt="">
                                </a>
                            </div>
                            <div class="bg-white p-4 space-x-2 max-w-sm mx-auto rounded-b-xl">
                                <div>
                                    <span class="px-2 py-1 rounded text-white bg-green-600 font-light text-sm"><?php echo e($course->Domaines[0]->label); ?></span>
                                    <span class="px-2 py-1 rounded text-white bg-green-600/[.2] font-medium text-sm text-green-600">Gratuit</span>
                                </div>
                                <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-2">
                                    <a href="<?php echo e($course->detailsUrl()); ?>">
                                        <?php echo e($course->title); ?>

                                    </a>
                                </div>
                                <div class=" flex justify-left gap-5 items-center">
                                    <img src="<?php echo e($course->Trainer->getFirstMediaUrl('trainers')); ?>" class="h-14 w-14 rounded-full  border border-etudes-blue" alt="">
                                    <span class="capitalize text-etudes-blue tracking-widest"><?php echo e($course->Trainer->first_name); ?> <?php echo e($course->Trainer->last_name); ?></span>
                                </div>
                            </div>
                            <div class="border-gray-300 border-t p-4 flex justify-between items-center">
                                <div class=" flex justify-between w-full items-center">
                                    <div class="flex justify-center items-center gap-4">
                                        <button class="text-xl px-2 p-1 rounded-lg bg-[#4267B2] hover:scale-150 duration-300">
                                            <i class="icofont-facebook text-white"></i>
                                        </button>
                                        <button class="text-xl px-2 p-1 rounded-lg bg-[#0077B5] hover:scale-150 duration-300">
                                            <i class="icofont-linkedin text-white"></i>
                                        </button>
                                        <button class="text-xl px-2 p-1 rounded-lg bg-[#1DA1F2] hover:scale-150 duration-300">
                                            <i class="icofont-twitter text-white"></i>
                                        </button>
                                    </div>
                                    <div class="text-sm">
                                        Ajouté le <?php echo e($course->carbonHumanDate()); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="grid place-items-center w-full col-span-2">
                            <div class="text-3xl font-bold text-gray-300">Aucun résultat</div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="mt-8">
                    <?php echo e($courses->links('vendor.pagination.customs')); ?>

                </div>
            </div>
            <div class="">
                <div class="mb-4">
                    <div class="text-xl pb-2 border-b">Articles récents</div>
                    <div class="">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex justify-left items-center gap-4 items-stretch my-6">
                                <a href="<?php echo e($article->detailsUrl()); ?>" class="w-1/3">
                                    <img src="<?php echo e($article->getFirstMediaUrl('articles')); ?>" class=" rounded-xl shadow-lg shadow-etudes-blue/[.6]" alt="">
                                </a>
                                <div class="w-2/3">
                                    <span class="py-1 px-2 text-violet-500 text-sm bg-violet-500/[.2] rounded-lg"> <?php echo e($article->Type->label); ?></span>
                                    <div class="mt-2 truncate text-etudes-blue">
                                        <a href="<?php echo e($article->detailsUrl()); ?>">
                                            <?php echo e($article->title); ?>

                                        </a>
                                    </div>
                                    <div class="text-xs font-thin">
                                        Publié le <?php echo e($article->carbonHumanDate()); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="mt-12 md:mt-16 mb-4">
                    <div class="text-xl pb-2 border-b">Certifications récentes</div>
                    <div class="">
                        <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex justify-left items-center gap-4 items-center my-6">
                                <a href="<?php echo e($certification->detailsUrl()); ?>" class="w-1/3">
                                    <img src="<?php echo e($certification->getFirstMediaUrl('certifications')); ?>" class="rounded-xl shadow-lg shadow-etudes-blue/[.6]" alt="">
                                </a>
                                <div class="w-2/3">
                                    <span class="py-1 px-2 text-violet-500 text-sm bg-violet-500/[.2] rounded-lg"><?php echo e($certification->Domaines[0]->label); ?></span>
                                    <div class="mt-2 truncate text-etudes-blue">
                                        <a href="<?php echo e($certification->detailsUrl()); ?>">
                                            <?php echo e($certification->title); ?>

                                        </a>
                                    </div>
                                    <div class="text-xs font-thin">
                                        Ajouté le <?php echo e($certification->carbonHumanDate()); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Liste des cours',
    'active' => 'courses',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/site/courses/list.blade.php ENDPATH**/ ?>