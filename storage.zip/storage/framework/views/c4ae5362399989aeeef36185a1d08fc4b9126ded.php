<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="badge-danger row mb-4 p-2 rounded text-center">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <div class="row mb-2">
        <div class="col-12 text-right">
            <a href="<?php echo e(route('admin.onlineClass.index')); ?>"><button class="btn btn-primary">Liste des online classrooms</button></a>
            <a href="<?php echo e(route('admin.onlineClass.trash')); ?>"><button class="btn btn-secondary">Corbeille</button></a>
        </div>
    </div>
    <form action="<?php echo e(route('admin.onlineClass.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-4 text-center">
                <div id="file-block ">
                    <label id="upload-label" class="upload-label">
                        <input name="image" class="file-input" id='image-input' onchange="handleImage(event)" type="file">
                        <i class="icofont-cloud-upload text-primary upload-icon"></i>
                    </label>
                    <div class="text-center">
                        <img id="image-preview" class="preview-image" src="" alt=""> <br>
                        <i id='delete-icon' class="icofont-ui-delete delete-image cursor-pointer d-none" onclick="dropImage()"></i>
                    </div>
                </div>
            </div>
            <div class="col-8 text-primary">
                <div class="row border-group">
                    <div class="col-6 form-group">
                        <label for="title" class="required">Titre</label>
                        <input value="<?php echo e(old('title')); ?>" type="text" name="title" class="form-control input-default " >
                    </div>
                    <div class="col-6 form-group">
                        <label for="trainer" class="required">Formateur</label>
                        <select value="<?php echo e(old('trainer')); ?>" name="trainer" class="form-control input-default">
                            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trainer->id); ?>"><?php echo e($trainer->last_name); ?> <?php echo e($trainer->first_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-6 form-group">
                        <label for="date" class="required">Date</label>
                        <input value="<?php echo e(old('date')); ?>" type="date" name="date" class="form-control input-default" >
                    </div>
                    <div class="col-6 form-group">
                        <label for="hour" class="required">Heure</label>
                        <input value="<?php echo e(old('hour')); ?>" type="time" name="hour" class="form-control input-default" >
                    </div>
                    <div class="col-12 form-group">
                        <label for="script" class="required">Script</label>
                        <input value="<?php echo e(old('script')); ?>" type="text" name="script" class="form-control input-default" >
                    </div>
                    <div class="col-12 form-group">
                        <label for="type" class="required">Type</label>
                        <select value="<?php echo e(old('type')); ?>" name="type" class="form-control input-default">
                            <option value="onlineclass" selected>Onlineclass</option>
                            <option value="webinaire">Webinaire</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label for="description" class="required">Description</label>
                        <textarea id="summernote" class="summernote" name="description">
                            <?php echo e(old('description')); ?>

                        </textarea>
                    </div>
                    <div class="col-12 mt-4">
                        <label for="description" class="required">Fichier Tokens</label><br>
                        <input type="file" accept=".csv" name="tokens">
                    </div>
                </div>
                <div class="my-4 text-center">
                    <button class="btn btn-primary">Enregistrer</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Créer une online class',
    'active' => 'online-class',
    'subActive' => 'online-class',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/admin/onlineclass/create.blade.php ENDPATH**/ ?>