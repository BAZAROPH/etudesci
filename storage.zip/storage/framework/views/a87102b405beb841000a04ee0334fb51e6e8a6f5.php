<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="badge-danger row mb-4 p-2 rounded text-center">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Liste des Abonnés</h4>
            </div>
            <div class="text-right mr-2">
                <button class="btn btn-primary" data-toggle="modal" data-target="#newSubscriber">Ajouter un(e) abonné(e)</button>
                 <!-- Modal -->
                <div class="modal fade" id="newSubscriber" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Ajouter un nouvel abonné</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('admin.addSubscriber')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <select name="email" class="multi-select text-left form form-control" id="">
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->email); ?>"><?php echo e($user->email); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="hidden" name="referenceNumber" id='references'>
                                    <div class="my-2">
                                        <label for="" class="required">Montant</label>
                                        <input type="text" class="form form-control" name="amount">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn btn-primary">Ajouter aux abonnés</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Début d'abonnement</th>
                                <th>Fin d'abonnement</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($subscriber->id); ?></td>
                                    <td><?php echo e($subscriber->last_name); ?></td>
                                    <td><?php echo e($subscriber->first_name); ?></td>
                                    <td><?php echo e($subscriber->Subscription->start); ?></td>
                                    <td><?php echo e($subscriber->Subscription->end); ?></td>
                                    <td>
                                        <?php if($subscriber->Subscription->state == 1 or $subscriber->Subscription->state == 2): ?>
                                            <span class="bg-success text-white p-2 rounded">En cours de validité</span>
                                        <?php else: ?>
                                            <span class="bg-danger text-white p-2 rounded">Expiré</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Début d'abonnement</th>
                                <th>Fin d'abonnement</th>
                                <th>Statut</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function generateTimestampKey() {
        return new Date().getTime().toString();
    }
    document.getElementById('references').value = generateTimestampKey();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste des Abonnés',
    'active' => 'subscribers',
    'subActive' => 'subscribers-list'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/admin/subscriptions/subscribers.blade.php ENDPATH**/ ?>