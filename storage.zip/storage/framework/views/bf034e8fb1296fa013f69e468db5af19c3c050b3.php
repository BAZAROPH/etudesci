<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="badge-danger row mb-4 p-2 rounded text-center">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 mx-4"><i class="bi bi-exclamation-triangle-fill pr-2"></i><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Liste des Abonnés</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="display" style="min-width: 845px">
                        <thead>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Email</th>
                                <th>Contact</th>
                                <th>Date d'insciption</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($potential->id); ?></td>
                                    <td><?php echo e($potential->last_name); ?></td>
                                    <td><?php echo e($potential->first_name); ?></td>
                                    <td><?php echo e($potential->email); ?></td>
                                    <td><?php echo e($potential->contact); ?></td>
                                    <td>
                                        <?php echo e($potential->created_at); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="text-center">
                                <th>Id</th>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Email</th>
                                <th>Contact</th>
                                <th>Date d'insciption</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base', [
    'title' => 'Liste des Abonnés',
    'active' => 'subscribers',
    'subActive' => 'potential-subscribers-list'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheickoumarcoulibaly/Documents/repository/etudesci-v3/resources/views/admin/subscriptions/potentialSubscribers.blade.php ENDPATH**/ ?>