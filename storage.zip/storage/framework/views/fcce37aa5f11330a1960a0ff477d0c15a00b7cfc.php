<?php $__env->startSection('content'); ?>
<div class="mb-16">
    <div class="h-56 bg-etudes-blue">
        <div class="md:mx-10 p-2 md:p-10 text-3xl md:text-5xl text-white grid place-items-center h-full">
            <div class="text-left w-full">
                <div class="font-semibold text-4xl line-clamp-2"><?php echo e($course->title); ?></div>
                <div class="h-10 bg-etudes-orange mt-4 rounded-lg flex items-center justify-left text-sm px-4 gap-4">
                    <div>
                        <a href="<?php echo e(route('home')); ?>">
                            Accueil
                        </a>
                    </div>
                    <span>-</span>
                        <a href="<?php echo e(route('book.list')); ?>" class="line-clamp-1">
                            Liste des cours
                        </a>
                    <span>-</span>
                    <div class="font-bold line-clamp-1">
                        <?php echo e($course->title); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="app" class="">

    </div>
</div>

<script type="text/javascript">
    var ROOT_URL = "<?php echo e(route('home')); ?>";
    var APP_NAME = "<?php echo e(config('app.name', 'Etudes.ci')); ?>";
    localStorage.setItem('token', "<?php echo e(session()->get('token')); ?>");
</script>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/courses/App.jsx'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => $course->title,
    'active' => 'courses',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/site/courses/follow/index.blade.php ENDPATH**/ ?>