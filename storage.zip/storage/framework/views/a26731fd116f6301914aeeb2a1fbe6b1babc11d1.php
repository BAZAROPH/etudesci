<?php $__env->startSection('content'); ?>
    <div>
        <img src="<?php echo e(asset('site/404.png')); ?>" class="" alt="">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Page Introuvable',
    'active' => '404',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/errors/404.blade.php ENDPATH**/ ?>