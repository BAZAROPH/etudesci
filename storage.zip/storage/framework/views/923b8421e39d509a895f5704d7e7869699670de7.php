<?php $__env->startSection('content'); ?>
    <div class="max-w-sm md:max-w-6xl my-8 mx-auto">
        <div>
            <img src="<?php echo e(asset('site/assets/test/pub_1672317136.png')); ?>" class="w-full" alt="">
        </div>

        
        <div class="my-10 md:grid md:grid-cols-2 gap-6">
            
            <div class="article-slide-horizontal">
                <?php $__currentLoopData = $left_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="">
                        <div>
                            <a href="<?php echo e($article->detailsUrl()); ?>">
                                <img src="<?php echo e($article->getFirstMediaUrl('articles')); ?>" alt="">
                            </a>
                        </div>
                        <div class="mt-2 font-thin space-x-2">
                            <i class="icofont-ui-calendar text-etudes-orange"></i>
                            <span> <?php echo e($article->carbonHumanDate()); ?></span>
                        </div>
                        <div class="mt-2 text-2xl">
                            <a href="<?php echo e($article->detailsUrl()); ?>">
                                <?php echo e($article->title); ?>

                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="article-slide-vertical mt-6 ùd:mt-0">
                <?php $__currentLoopData = $right_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-4">
                        <div class="grid grid-cols-3 gap-4">
                            <div>
                                <a href="<?php echo e($article->detailsUrl()); ?>">
                                    <img src="<?php echo e($article->getFirstMediaUrl('articles')); ?>" class="h-36" alt="">
                                </a>
                            </div>
                            <div class="col-span-2">
                                <div class="mt-2 font-thin space-x-2">
                                    <i class="icofont-ui-calendar text-etudes-orange"></i>
                                    <span><?php echo e($article->carbonHumanDate()); ?></span>
                                </div>
                                <div class="mt-2 text-2xl">
                                    <a href="<?php echo e($article->detailsUrl()); ?>">
                                        <?php echo e($article->title); ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="mb-10 mt-16">
            <div class="text-center w-full relative">
                <div class="text-4xl capitalize">Cours en ligne gratuits</div>
                <div class="mt-2 font-light text-sm">Pour renforcer vos capacités professionnelles.</div>
            </div>

            <div class="mt-6">
                <div class="course-slide w-full">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white shadow-xl <?php echo e($course->type == 'onlineclass' ? 'shadow-etudes-orange rounded-xl' : ''); ?>">
                            <div>
                                <a href="<?php echo e($course->detailsUrl()); ?>">
                                    <img src="<?php echo e($course->getFirstMediaUrl('courses')); ?>" class="h-64 w-full mx-auto" alt="">
                                </a>
                            </div>
                            <div class="bg-white p-4 space-x-2 max-w-sm mx-auto <?php echo e($course->type == 'onlineclass' ? 'rounded-xl' : ''); ?>">
                                <div>
                                    <span class="px-2 py-1 rounded text-white bg-green-600 font-light text-sm">Communication</span>
                                    <span class="px-2 py-1 rounded text-white bg-green-600/[.2] font-medium text-sm text-green-600">Gratuit</span>
                                </div>
                                <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-2">
                                    <a href="<?php echo e($course->detailsUrl()); ?>">
                                        <?php echo e($course->title); ?>

                                    </a>
                                </div>
                                <div class="border-t border-gray-400 p-3 flex justify-left gap-5 items-center">
                                    <img src="<?php echo e($course->Trainer->getFirstMediaUrl('trainers')); ?>" class="h-14 w-14 rounded-full  border border-etudes-blue" alt="">
                                    <span class="capitalize text-etudes-blue tracking-widest"><?php echo e($course->Trainer->first_name); ?> <?php echo e($course->Trainer->last_name); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <div class="mt-5 text-center">
                    <a href="<?php echo e(route('course.list')); ?>">
                        <button class="bg-etudes-blue text-white py-2 px-3 rounded hover:scale-110 duration-300 hover:bg-etudes-orange hover:shadow-xl">Voir tous les cours <i class="icofont-rounded-double-right"></i></button>
                    </a>
                </div>
            </div>
        </div>

        <hr>

        
        <div class="mb-10 mt-14">
            <div class="text-center w-full relative">
                <div class="text-4xl capitalize">Certifications</div>
                <div class="mt-2 font-light text-sm max-w-md mx-auto">Un accès à des certificats de qualité, fiables et adaptés à vos besoins de renforcement de capacités professionnelles.</div>
            </div>

            <div class="mt-6">
                <div class="w-full course-slide">
                    <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="shadow-xl border rounded-xl h-full">
                            <div class="w-full">
                                <a href="<?php echo e($certification->detailsUrl()); ?>">
                                    <img src="<?php echo e($certification->getFirstMediaUrl('certifications')); ?>" class="h-96 w-full " alt="">
                                </a>
                            </div>
                            <div class="p-4">
                                <div class="flex justify-between items-center text-gray-500">
                                    <div class="gap-4 flex items-center">
                                        <i class="icofont-ui-calendar text-etudes-orange"></i>
                                        <span><?php echo e($certification->carbonHumanDate()); ?></span>
                                    </div>
                                    <div>
                                        <i class="icofont-location-pin text-etudes-blue"></i>
                                        <?php if($certification->location_type == 'online'): ?>
                                            En ligne
                                        <?php else: ?>
                                            En présentiel
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-1">
                                    <a href="<?php echo e($certification->detailsUrl()); ?>">
                                        <?php echo e($certification->title); ?>

                                    </a>
                                </div>
                                <div class=" flex justify-left gap-5 items-center">
                                    <img src="<?php echo e(asset('site/assets/test/certificats_1662043814.png')); ?>" class="h-14 w-14 rounded-full  border border-etudes-blue" alt="">
                                    <span class="capitalize text-etudes-blue tracking-widest"><?php echo e($certification->Office->name); ?></span>
                                </div>
                            </div>
                            <div class="border-gray-300 border-t p-4 flex justify-between items-center">
                                <span class="text-green-500 font-bold text-xl">
                                    <?php if($certification->reduction): ?>
                                        <?php echo number_format($certification->price - ($certification->price * ($certification->reduction/100))). ' Fcfa'; ?>
                                    <?php else: ?>
                                        <?php echo number_format($certification->price). ' Fcfa'; ?>
                                    <?php endif; ?>
                                </span>
                                <a href="<?php echo e($certification->detailsUrl()); ?>" class="hover:text-etudes-blue hover:scale-105 duration-300">
                                    <span class="font-medium">Détails</span>
                                    <i class="icofont-arrow-right text-lg"></i>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-5 text-center">
                    <a href="<?php echo e(route('certification.list')); ?>">
                        <button class="bg-etudes-blue text-white py-2 px-3 rounded hover:scale-110 duration-300 hover:bg-etudes-orange hover:shadow-xl">Voir toutes les certifications <i class="icofont-rounded-double-right"></i></button>
                    </a>
                </div>
            </div>
        </div>

        <hr>

        
        <div class="mb-10 mt-14">
            <div class="text-center w-full relative">
                <div class="text-4xl capitalize">Evènements professionnels </div>
                <div class="mt-2 font-light text-sm max-w-md mx-auto">Participez aux évènements qui vous rapprochent de vos objectifs, et agrandissez votre reseau professionnel.</div>
            </div>

            <div class="mt-6">
                <div class="w-full course-slide">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="shadow-xl border rounded-xl">
                            <div class="w-full">
                                <a href="<?php echo e($event->detailsUrl()); ?>">
                                    <img src="<?php echo e($event->getFirstMediaUrl('events')); ?>" class="h-80 w-full rounded-t-xl" alt="">
                                </a>
                            </div>
                            <div class="p-4">
                                <div class="flex justify-left items-center gap-2 text-gray-500 text-sm">
                                    <div class=" gap-2 flex items-center">
                                        <i class="icofont-ui-calendar text-etudes-orange"></i>
                                        <span><?php echo e($event->carbonHumanDate()); ?></span>
                                    </div>
                                    <div>|</div>
                                    <div>
                                        <i class="icofont-stopwatch text-etudes-blue"></i>
                                        <span><?php echo e($event->carbonHumanHour()); ?> GMT</span>
                                    </div>
                                </div>
                                <div class="text-xl font-semibold text-etudes-blue my-4 line-clamp-1">
                                    <?php echo e($event->name); ?>

                                </div>
                            </div>
                            <div class="border-gray-300 border-t p-4">
                                <i class="icofont-location-arrow text-etudes-blue"></i>
                                <?php echo e($event->place); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', [
    'title' => 'Accueil',
    'active' => 'home',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cheick/Documents/repository/etudesci-v3/resources/views/site/home.blade.php ENDPATH**/ ?>